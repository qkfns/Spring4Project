create definer = playground@`%` view 제조업체별제품수 as
select `playground`.`sales_products`.`sprdmaker` AS `제조업체`, count(`playground`.`sales_products`.`sprdid`) AS `제품수`
from `playground`.`sales_products`
group by `playground`.`sales_products`.`sprdmaker`;

