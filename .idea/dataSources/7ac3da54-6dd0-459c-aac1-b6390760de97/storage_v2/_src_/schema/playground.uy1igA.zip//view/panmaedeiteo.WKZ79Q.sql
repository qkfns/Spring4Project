create definer = playground@`%` view 판매데이터 as
select `playground`.`sales_orders`.`scustid`         AS `scustid`,
       `playground`.`sales_orders`.`sprdid`          AS `sprdid`,
       `playground`.`sales_orders`.`ordno`           AS `ordno`,
       `playground`.`sales_orders`.`ordstatus`       AS `ordstatus`,
       `playground`.`sales_orders`.`ordadress`       AS `ordadress`,
       `playground`.`sales_orders`.`orddate`         AS `orddate`,
       `playground`.`sales_products`.`sprdname`      AS `sprdname`,
       `playground`.`sales_products`.`invent`        AS `invent`,
       `playground`.`sales_products`.`sprdprice`     AS `sprdprice`,
       `playground`.`sales_products`.`sprdmaker`     AS `sprdmaker`,
       `playground`.`sales_customers`.`scustname`    AS `scustname`,
       `playground`.`sales_customers`.`scustage`     AS `scustage`,
       `playground`.`sales_customers`.`scustgrd`     AS `scustgrd`,
       `playground`.`sales_customers`.`scustjob`     AS `scustjob`,
       `playground`.`sales_customers`.`scustmileage` AS `scustmileage`
from ((`playground`.`sales_orders` join `playground`.`sales_products` on (`playground`.`sales_orders`.`sprdid` =
                                                                          `playground`.`sales_products`.`sprdid`))
         join `playground`.`sales_customers`
              on (`playground`.`sales_orders`.`scustid` = `playground`.`sales_customers`.`scustid`));

