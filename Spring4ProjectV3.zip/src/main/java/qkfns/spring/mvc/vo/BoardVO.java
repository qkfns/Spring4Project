package qkfns.spring.mvc.vo;

public class BoardVO {
}
