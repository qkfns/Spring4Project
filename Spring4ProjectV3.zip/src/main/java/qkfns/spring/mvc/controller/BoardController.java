package qkfns.spring.mvc.controller;

public class BoardController {
}
