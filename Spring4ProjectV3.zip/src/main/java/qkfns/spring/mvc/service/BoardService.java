package qkfns.spring.mvc.service;

public interface BoardService {
}
