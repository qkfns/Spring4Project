package qkfns.spring.mvc.service;

public class BoardServiceImpl {
}
