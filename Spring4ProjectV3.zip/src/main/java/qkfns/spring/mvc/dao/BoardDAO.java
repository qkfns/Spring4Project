package qkfns.spring.mvc.dao;

public interface BoardDAO {
}
