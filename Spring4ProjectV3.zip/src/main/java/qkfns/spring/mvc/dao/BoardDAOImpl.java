package qkfns.spring.mvc.dao;

public class BoardDAOImpl {
}
