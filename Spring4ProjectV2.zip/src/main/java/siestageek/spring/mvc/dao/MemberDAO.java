package siestageek.spring.mvc.dao;

import siestageek.spring.mvc.vo.MemberVO;

public interface MemberDAO {
    int insertMember(MemberVO mvo);
}
