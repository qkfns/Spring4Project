-- member
create table Member (
mno int primary key auto_increment,
    name varchar(20) not null,
    jumin varchar(14) not null,
    userid varchar(16) not null,
    passwd varchar(16) not null,
    zipcode varchar(7) not null,
    addr1 varchar(50) not null,
    addr2 varchar(50) not null,
    email varchar(50) not null,
    phone varchar(13) not null,
    regdate timestamp default current_timestamp
);

-- CRUD
insert into Member
(name, jumin, userid, passwd, zipcode, addr1, addr2, email, phone)
values (?,?,?,?,?,?,?,?,?);




